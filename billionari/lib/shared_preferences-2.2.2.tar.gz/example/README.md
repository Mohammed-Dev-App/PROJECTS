# shared_preferences_example

Demonstrates how to use the shared_preferences plugin.
